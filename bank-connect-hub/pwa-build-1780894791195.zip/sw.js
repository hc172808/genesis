/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-b6866b34'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();

  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "844e69c088ed19f691f19c88680818b3"
  }, {
    "url": "icon.svg",
    "revision": "4ab4d300801f7b8d06de8ab790bb1254"
  }, {
    "url": "favicon.ico",
    "revision": "566e64364d6957715dc11845f4800700"
  }, {
    "url": "assets/zap-XeQVU3IV.js",
    "revision": null
  }, {
    "url": "assets/wifi-BJBpqTlh.js",
    "revision": null
  }, {
    "url": "assets/whatsapp-BiLZ1TCy.js",
    "revision": null
  }, {
    "url": "assets/wallet-Dtlx2MMG.js",
    "revision": null
  }, {
    "url": "assets/wallet-B19Qe6-i.js",
    "revision": null
  }, {
    "url": "assets/users-DFSE1qpd.js",
    "revision": null
  }, {
    "url": "assets/user-D5xLMKam.js",
    "revision": null
  }, {
    "url": "assets/useDashboardHome-zrgv-Fcm.js",
    "revision": null
  }, {
    "url": "assets/upload-0Bw2YWOX.js",
    "revision": null
  }, {
    "url": "assets/trending-up-BUHjMgMy.js",
    "revision": null
  }, {
    "url": "assets/trending-down-DWem1r_l.js",
    "revision": null
  }, {
    "url": "assets/trash-2-CR23Mooo.js",
    "revision": null
  }, {
    "url": "assets/toggle-left-DgR2Tus8.js",
    "revision": null
  }, {
    "url": "assets/textarea--zRleZJU.js",
    "revision": null
  }, {
    "url": "assets/terminal-BMgU1wQm.js",
    "revision": null
  }, {
    "url": "assets/tabs-DmJHtHK0.js",
    "revision": null
  }, {
    "url": "assets/table-eaR4-ePk.js",
    "revision": null
  }, {
    "url": "assets/switch-Bq0hv9xH.js",
    "revision": null
  }, {
    "url": "assets/store-asHZV2UF.js",
    "revision": null
  }, {
    "url": "assets/star-Cj9YmEEL.js",
    "revision": null
  }, {
    "url": "assets/square-Cu5dyfO7.js",
    "revision": null
  }, {
    "url": "assets/shield-off-BB_ZCn92.js",
    "revision": null
  }, {
    "url": "assets/shield-check-DnL3rYiU.js",
    "revision": null
  }, {
    "url": "assets/shield-alert-VI1Hqp7L.js",
    "revision": null
  }, {
    "url": "assets/shield-CRSWs7i9.js",
    "revision": null
  }, {
    "url": "assets/share-2-DkAJQFeD.js",
    "revision": null
  }, {
    "url": "assets/separator-DbmGcoJK.js",
    "revision": null
  }, {
    "url": "assets/send-_XG3p45P.js",
    "revision": null
  }, {
    "url": "assets/select-CohYtj4D.js",
    "revision": null
  }, {
    "url": "assets/search-v5nseUHO.js",
    "revision": null
  }, {
    "url": "assets/save-C06IzM9s.js",
    "revision": null
  }, {
    "url": "assets/rotate-ccw-4uSUBAiW.js",
    "revision": null
  }, {
    "url": "assets/receipt-Dw8F_Y4f.js",
    "revision": null
  }, {
    "url": "assets/radio-group-B1kF5-Iu.js",
    "revision": null
  }, {
    "url": "assets/qr-code-BgXv_eWX.js",
    "revision": null
  }, {
    "url": "assets/provider-jsonrpc-CsPW5DIX.js",
    "revision": null
  }, {
    "url": "assets/printer-0G9H5ELh.js",
    "revision": null
  }, {
    "url": "assets/plus-wNKPB4Ka.js",
    "revision": null
  }, {
    "url": "assets/phone-Bam-DMA6.js",
    "revision": null
  }, {
    "url": "assets/percent-C5H9nxEX.js",
    "revision": null
  }, {
    "url": "assets/pencil-CKnv4zpj.js",
    "revision": null
  }, {
    "url": "assets/pen-qLGIKABF.js",
    "revision": null
  }, {
    "url": "assets/palette-BaLZXaTh.js",
    "revision": null
  }, {
    "url": "assets/package-CMAlZ1fu.js",
    "revision": null
  }, {
    "url": "assets/message-square-CnsPxxCr.js",
    "revision": null
  }, {
    "url": "assets/megaphone-CnpLOp-k.js",
    "revision": null
  }, {
    "url": "assets/map-pin-CiCPTr5N.js",
    "revision": null
  }, {
    "url": "assets/log-out-CHqbWLkC.js",
    "revision": null
  }, {
    "url": "assets/lock-Cc_bmeM9.js",
    "revision": null
  }, {
    "url": "assets/loader-circle-7OmJ6pwt.js",
    "revision": null
  }, {
    "url": "assets/link-2-C15HU18C.js",
    "revision": null
  }, {
    "url": "assets/label-CYlTQInc.js",
    "revision": null
  }, {
    "url": "assets/input-CsT1eicA.js",
    "revision": null
  }, {
    "url": "assets/info-BnU5dlsg.js",
    "revision": null
  }, {
    "url": "assets/index-kyQB_20e.css",
    "revision": null
  }, {
    "url": "assets/index-GRttLzq8.js",
    "revision": null
  }, {
    "url": "assets/index-DuA52bGI.js",
    "revision": null
  }, {
    "url": "assets/index-CkJsOxL7.js",
    "revision": null
  }, {
    "url": "assets/index-Cir5Y0MJ.js",
    "revision": null
  }, {
    "url": "assets/index-C3JiT95N.js",
    "revision": null
  }, {
    "url": "assets/index-C1ygCfW4.js",
    "revision": null
  }, {
    "url": "assets/index-BVgRqkp2.js",
    "revision": null
  }, {
    "url": "assets/globe-D1vldKgn.js",
    "revision": null
  }, {
    "url": "assets/gift-D97kstvO.js",
    "revision": null
  }, {
    "url": "assets/format-B4HGtso5.js",
    "revision": null
  }, {
    "url": "assets/file-text-zsKamTKL.js",
    "revision": null
  }, {
    "url": "assets/file-check-GbjGzox_.js",
    "revision": null
  }, {
    "url": "assets/file-archive-ClWAj02a.js",
    "revision": null
  }, {
    "url": "assets/eye-off-DMi7ucUE.js",
    "revision": null
  }, {
    "url": "assets/eye-b-GpQZPY.js",
    "revision": null
  }, {
    "url": "assets/external-link-ByYo0G4i.js",
    "revision": null
  }, {
    "url": "assets/dollar-sign-BYv955l2.js",
    "revision": null
  }, {
    "url": "assets/dialog-CAHvs4CX.js",
    "revision": null
  }, {
    "url": "assets/database-DonDK-1z.js",
    "revision": null
  }, {
    "url": "assets/credit-card-fn2zmtNz.js",
    "revision": null
  }, {
    "url": "assets/cpu-CFhpKFu7.js",
    "revision": null
  }, {
    "url": "assets/copy-B17kn96Z.js",
    "revision": null
  }, {
    "url": "assets/coins-CC8QTpEe.js",
    "revision": null
  }, {
    "url": "assets/clock-Cd5Jj4Cy.js",
    "revision": null
  }, {
    "url": "assets/circle-x-C-y3vYii.js",
    "revision": null
  }, {
    "url": "assets/circle-check-big-TIaOiyPK.js",
    "revision": null
  }, {
    "url": "assets/circle-check-CLnXdkPM.js",
    "revision": null
  }, {
    "url": "assets/check-B5L7PNNf.js",
    "revision": null
  }, {
    "url": "assets/card-CjBWgBPV.js",
    "revision": null
  }, {
    "url": "assets/camera-BzN5SfWh.js",
    "revision": null
  }, {
    "url": "assets/building-B8oxDdV9.js",
    "revision": null
  }, {
    "url": "assets/brain-4QSjciBX.js",
    "revision": null
  }, {
    "url": "assets/biometricAuth-NojK0uYm.js",
    "revision": null
  }, {
    "url": "assets/bell-Nq3df1u2.js",
    "revision": null
  }, {
    "url": "assets/badge-BZbTybtQ.js",
    "revision": null
  }, {
    "url": "assets/avatar-B_bCKdEY.js",
    "revision": null
  }, {
    "url": "assets/arrow-up-right-2utpHVKE.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-left-CDOdA3FT.js",
    "revision": null
  }, {
    "url": "assets/arrow-left-wGsvpLwV.js",
    "revision": null
  }, {
    "url": "assets/arrow-down-left-BqTDbRmG.js",
    "revision": null
  }, {
    "url": "assets/apple-DrnBIMeJ.js",
    "revision": null
  }, {
    "url": "assets/aiSecurity-CKg1pb-3.js",
    "revision": null
  }, {
    "url": "assets/aiFirewall-DvJICUbN.js",
    "revision": null
  }, {
    "url": "assets/activity-Dz59Qk4r.js",
    "revision": null
  }, {
    "url": "assets/VerifyWhatsApp-BQWSpHkz.js",
    "revision": null
  }, {
    "url": "assets/VendorStore-D_ADqWAb.js",
    "revision": null
  }, {
    "url": "assets/VendorRegistrationFees-0O7A_GnH.js",
    "revision": null
  }, {
    "url": "assets/VendorList-BjyNJTic.js",
    "revision": null
  }, {
    "url": "assets/VendorDashboard-DrmR28Ha.js",
    "revision": null
  }, {
    "url": "assets/VendorCharge-COCQi6sV.js",
    "revision": null
  }, {
    "url": "assets/VendorAnalytics-eTcq_QoR.js",
    "revision": null
  }, {
    "url": "assets/UserAnalytics-BwXzMveK.js",
    "revision": null
  }, {
    "url": "assets/Transactions-DE9tZXrR.js",
    "revision": null
  }, {
    "url": "assets/TransactionReports-hdeHtZ1l.js",
    "revision": null
  }, {
    "url": "assets/TopUp-iTtWUZN5.js",
    "revision": null
  }, {
    "url": "assets/SystemSettings-Bt6YCvrf.js",
    "revision": null
  }, {
    "url": "assets/SetPinDialog-B6-iEK8d.js",
    "revision": null
  }, {
    "url": "assets/SendMoney-CwY12xfA.js",
    "revision": null
  }, {
    "url": "assets/SecuritySettings-B4Sd3TQK.js",
    "revision": null
  }, {
    "url": "assets/ScanToPay-D4grel9e.js",
    "revision": null
  }, {
    "url": "assets/ResetPassword-D7MJIWNP.js",
    "revision": null
  }, {
    "url": "assets/RequestReversal-frreBhMr.js",
    "revision": null
  }, {
    "url": "assets/RequestFunds-vn7JPCyJ.js",
    "revision": null
  }, {
    "url": "assets/Register-BBo9u7jZ.js",
    "revision": null
  }, {
    "url": "assets/ReferAndEarn-Dn1HV_ss.js",
    "revision": null
  }, {
    "url": "assets/ReceiveMoney-DyBsoiaQ.js",
    "revision": null
  }, {
    "url": "assets/QRScanner-CAtXd0IB.js",
    "revision": null
  }, {
    "url": "assets/Profile-BbZk8b7l.js",
    "revision": null
  }, {
    "url": "assets/PayMerchant-DKEQGEUl.js",
    "revision": null
  }, {
    "url": "assets/PayBills-C-FiaFpc.js",
    "revision": null
  }, {
    "url": "assets/Notifications-BC_tr7k2.js",
    "revision": null
  }, {
    "url": "assets/NotificationBell-DGuND9BI.js",
    "revision": null
  }, {
    "url": "assets/NotFound-lMwXp72O.js",
    "revision": null
  }, {
    "url": "assets/MyQRCode-Li0gOsJH.js",
    "revision": null
  }, {
    "url": "assets/Menu-Du1IOaxt.js",
    "revision": null
  }, {
    "url": "assets/ManageVendors-D0ntRsOa.js",
    "revision": null
  }, {
    "url": "assets/ManageUsers-CGQSjxiy.js",
    "revision": null
  }, {
    "url": "assets/ManageReversals-D5iikwZv.js",
    "revision": null
  }, {
    "url": "assets/ManageMobileProviders-BKAwbACa.js",
    "revision": null
  }, {
    "url": "assets/ManageChangelog-CvGMZdDE.js",
    "revision": null
  }, {
    "url": "assets/ManageAgents-sIfGCNrY.js",
    "revision": null
  }, {
    "url": "assets/KYCSubmission-DqJDI8xC.js",
    "revision": null
  }, {
    "url": "assets/ForgotPassword-CSfQ5mGP.js",
    "revision": null
  }, {
    "url": "assets/FinancialReports-D4keH2LA.js",
    "revision": null
  }, {
    "url": "assets/Feedback-Tl_ixbqg.js",
    "revision": null
  }, {
    "url": "assets/FeeManagement-BMT7hFpp.js",
    "revision": null
  }, {
    "url": "assets/FeatureToggles-Cb0MwloC.js",
    "revision": null
  }, {
    "url": "assets/DatabaseManagement-CmioCZLL.js",
    "revision": null
  }, {
    "url": "assets/ConversionFees-D8hje2zm.js",
    "revision": null
  }, {
    "url": "assets/Combination-C8LTqK39.js",
    "revision": null
  }, {
    "url": "assets/CoinManagement-7nXL6jEj.js",
    "revision": null
  }, {
    "url": "assets/CoinConvert-DW1vI5M5.js",
    "revision": null
  }, {
    "url": "assets/ClientDashboard-8lMsLRkj.js",
    "revision": null
  }, {
    "url": "assets/ChangePassword-Dq4EqqyR.js",
    "revision": null
  }, {
    "url": "assets/BlockchainSettings-DOpuv_Xh.js",
    "revision": null
  }, {
    "url": "assets/Auth-BSEg8P6n.js",
    "revision": null
  }, {
    "url": "assets/ApprovePendingDeposits-ITdGwlw_.js",
    "revision": null
  }, {
    "url": "assets/AgentDeposit-CpsDLelx.js",
    "revision": null
  }, {
    "url": "assets/AgentDashboard-mMsstbLf.js",
    "revision": null
  }, {
    "url": "assets/AdminThemes-Btl9AukK.js",
    "revision": null
  }, {
    "url": "assets/AdminSuspiciousAlerts-BKywq4y7.js",
    "revision": null
  }, {
    "url": "assets/AdminPrintQRCodes-BJ7pUDOx.js",
    "revision": null
  }, {
    "url": "assets/AdminNotifications-Ce745l-k.js",
    "revision": null
  }, {
    "url": "assets/AdminLitenode-0JvXHUcr.js",
    "revision": null
  }, {
    "url": "assets/AdminKYCReview-CjASBu2Z.js",
    "revision": null
  }, {
    "url": "assets/AdminFirewall-BSLgGAuf.js",
    "revision": null
  }, {
    "url": "assets/AdminDeposit-CZvAB3mz.js",
    "revision": null
  }, {
    "url": "assets/AdminDashboard-SKjBTnIZ.js",
    "revision": null
  }, {
    "url": "assets/AdminCountries-DBVHvNeA.js",
    "revision": null
  }, {
    "url": "assets/AdminConsole-ByyiyYWi.js",
    "revision": null
  }, {
    "url": "assets/AdminAuditLogs-CQ-4phEy.js",
    "revision": null
  }, {
    "url": "assets/AdminAppReleases-BRpiXlrt.js",
    "revision": null
  }, {
    "url": "assets/AdminAppManager-C-wgwZps.js",
    "revision": null
  }, {
    "url": "assets/AdminApkBuilder-BzBS-Hv9.js",
    "revision": null
  }, {
    "url": "assets/AdminAnnouncements-igEgYTn7.js",
    "revision": null
  }, {
    "url": "assets/AdminAISecurity-CeUsEiGx.js",
    "revision": null
  }, {
    "url": "assets/AddMoneyMobile-aA1NCJN6.js",
    "revision": null
  }, {
    "url": "assets/AddMoneyCard-CuuKNGIZ.js",
    "revision": null
  }, {
    "url": "assets/AddMoneyBank-Ci6ihqwd.js",
    "revision": null
  }, {
    "url": "assets/AddMoneyAgent-CSM0UKwi.js",
    "revision": null
  }, {
    "url": "assets/AddMoney-BY6lDEZ8.js",
    "revision": null
  }, {
    "url": "favicon.ico",
    "revision": "566e64364d6957715dc11845f4800700"
  }, {
    "url": "icon.svg",
    "revision": "4ab4d300801f7b8d06de8ab790bb1254"
  }, {
    "url": "robots.txt",
    "revision": "f9dff89adf98833e676de2205921996a"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1c5ad70ed439d81ad9eec2b0a6c4c9aa"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/api\//]
  }));
  workbox.registerRoute(({
    url
  }) => /\.(?:png|jpg|jpeg|svg|gif|webp)$/i.test(url.pathname), new workbox.CacheFirst({
    "cacheName": "img-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 80,
      maxAgeSeconds: 2592000
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.hostname.endsWith("supabase.co"), new workbox.NetworkFirst({
    "cacheName": "api-cache",
    "networkTimeoutSeconds": 6,
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 60,
      maxAgeSeconds: 300
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
