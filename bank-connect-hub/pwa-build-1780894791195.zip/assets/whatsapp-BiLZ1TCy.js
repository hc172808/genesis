import{c as o}from"./index-DuA52bGI.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=o("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]),r="+15555555555",a="vb.whatsappVerification",l=()=>Math.floor(1e5+Math.random()*9e5).toString(),d=(t,e)=>`https://wa.me/${(t||r).replace(/[^\d]/g,"")}?text=${encodeURIComponent(e)}`,g=t=>{try{localStorage.setItem(a,JSON.stringify(t))}catch{}},s=t=>{try{const e=localStorage.getItem(a);if(!e)return null;const n=JSON.parse(e);return n.userId===t?n:null}catch{return null}},p=t=>{const e=s(t);return!!(e!=null&&e.confirmedAt)};export{i as M,r as W,l as a,d as b,s as g,p as i,g as s};
